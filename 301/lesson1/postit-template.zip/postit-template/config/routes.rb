PostitTemplate::Application.routes.draw do
  root to: 'posts#index'
end
